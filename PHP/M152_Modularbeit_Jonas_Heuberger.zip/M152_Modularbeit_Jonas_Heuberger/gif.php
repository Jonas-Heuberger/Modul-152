<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php include('Include/header.php'); ?>
    <img src="Multimedia/GIF/GIF.gif">
    <div>
       <p>Untertitel</p> 
       <p>Grösse: 959 KB</p>

    </div>
</body>
</html>