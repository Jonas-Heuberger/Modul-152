<?php
$textHead = 'Jonas';
$logo = 'Multimedia/Pictures/Logo.jpeg';
$textFoot = 'Heuberger'; 
?>